//
//  ContentView.swift
//  JOJO
//
//  Created by William Bateman on 6/17/21.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
        
        ZStack {
            
            
            LinearGradient(gradient: Gradient(colors: [.black,.purple,.black]), startPoint: .top, endPoint: .bottom).ignoresSafeArea()
           
            
            
            ScrollView {
            
               
                VStack {
            
                    
                    
                    NavigationLink(
                        destination: JJBA_View(),
                        label: {
                        
                            ZStack {
                            
                                Rectangle()
                                    .cornerRadius(20.0)
                                    .padding(.all, 5.0)
                                    .foregroundColor(.black)
                                    .opacity(0.5)
                                    .shadow(radius: 20)
                                
                                
                                
                            VStack {
                            
                                Image("JJBA")
                                    .resizable()
                                    .cornerRadius(20.0)
                                    .padding(15.0)
                                    .scaledToFit()
                            
                                Text("Jojo's Bizarre Adventure: The Animation")
                                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding(.bottom, 30.0)
                            }
                            }
                        })
                    
                    NavigationLink(
                        destination: Stardust_Char_View(),
                        label: {
                            
                            ZStack {
                            
                                Rectangle()
                                    .cornerRadius(20.0)
                                    .padding(.all, 5.0)
                                    .foregroundColor(.black)
                                    .opacity(0.5)
                                    .shadow(radius: 20)
                                
                                
                            VStack {
                                
                                Image("Stardust C")
                                    .resizable()
                                    .cornerRadius(20.0)
                                    .padding(20.0)
                                    .scaledToFit()
                                
                                Text("Stardust Crusaders")
                                    .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                                    .font(.headline)
                                        .foregroundColor(.white)
                                    .padding(.bottom, 30.0)
                            }
                            }
                        })
                    
                   NavigationLink(
                    destination: Diamond_Char_View(),
                    label: {
                        
                        ZStack {
                        
                            Rectangle()
                                .cornerRadius(20.0)
                                .padding(.all, 5.0)
                                .foregroundColor(.black)
                                .opacity(0.5)
                                .shadow(radius: 20)
                            
                        VStack {
                            
                            Image("Diamond")
                                .resizable()
                                .cornerRadius(20.0)
                                .padding(20.0)
                                .scaledToFit()
                            
                            Text("Diamond is Unbreakable")
                                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                                .font(.headline)
                                    .foregroundColor(.white)
                                    .padding(.bottom, 30.0)
                        }
                        }
                    })
                    
                   NavigationLink(
                    destination: Golden_Wind_Char_View(),
                    label: {
                       
                        ZStack {
                        
                            Rectangle()
                                .cornerRadius(20.0)
                                .padding(.all, 5.0)
                                .foregroundColor(.black)
                                .opacity(0.5)
                                .shadow(radius: 20)
                            
                        VStack {
                            Image("Golden Wind")
                                .resizable()
                                .cornerRadius(20.0)
                                .padding(15.0)
                                .scaledToFit()
                            
                            Text("Jojo's Bizarre Adventure: Golden Wind")
                                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                                .font(.headline)
                                    .foregroundColor(.white)
                                    .padding(.bottom, 30.0)
                            
                            
                            
                        }
                        }
                    })
                    
                    
                    
                   
                    
                    
                    
                
                
                    
                }
            }
            
        }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
            ContentView()
        }
    }
}
