//
//  JOJOApp.swift
//  JOJO
//
//  Created by William Bateman on 6/17/21.
//

import SwiftUI

@main
struct JOJOApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
