//
//  Will. A. Zeppeli.swift
//  JOJO
//
//  Created by William Bateman on 6/18/21.
//

import SwiftUI

struct Will__A__Zeppeli: View {
    var body: some View {
        ZStack {
            
            LinearGradient(gradient: Gradient(colors: [.black,.purple,.black]), startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            
            
            
            
            
        }
    }
}

struct Will__A__Zeppeli_Previews: PreviewProvider {
    static var previews: some View {
        Will__A__Zeppeli()
    }
}
