//
//  Stardust Char View.swift
//  JOJO
//
//  Created by William Bateman on 6/17/21.
//

import SwiftUI

struct Stardust_Char_View: View {
    
    let columns: [GridItem] = [GridItem(),GridItem()]
    
    var body: some View {
      
        ZStack {
            
            LinearGradient(gradient: Gradient(colors: [.black,.purple,.black]), startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            
            ScrollView {
                
                VStack {
                
                    VStack {
                
                        LazyVGrid(columns: columns, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, spacing: /*@START_MENU_TOKEN@*/nil/*@END_MENU_TOKEN@*/, pinnedViews: /*@START_MENU_TOKEN@*/[]/*@END_MENU_TOKEN@*/, content: {
                    
                
                    
                            NavigationLink(
                                destination: JonathanJoestar(),
                                label: {
                            
                                    ZStack {
                            
                                Rectangle()
                                    .opacity(0.5)
                                    .cornerRadius(20)
                                    .foregroundColor(.black)
                                    
                                
                            VStack {
                            
                            Image("JonathanJoestar")
                                .resizable(capInsets: EdgeInsets())
                                .aspectRatio(contentMode: .fit)
                                .scaledToFit()
                                .cornerRadius(20)
                                
                            
                                Text("Jonathan Joestar")
                                    .padding(.bottom)
                            
                            }
                            .padding([.top, .leading, .trailing]).foregroundColor(.white)
                            
                            
                            }
                            })
                    
                    NavigationLink(
                        destination: Will__A__Zeppeli(),
                        label: {
                            
                            ZStack {
                            
                                Rectangle()
                                    .opacity(0.5)
                                    .cornerRadius(20)
                                    .foregroundColor(.black)
                                    
                                
                            VStack {
                            
                            Image("William A. Zeppeli")
                                .resizable()
                                .scaledToFit()
                                .cornerRadius(20)
                                
                            
                                Text("William A. Zeppeli")
                                    .padding(.bottom)
                            
                            }
                            .padding([.top, .leading, .trailing]).foregroundColor(.white)
                            
                            
                            }
                            })
                    
                    NavigationLink(
                        destination: Will__A__Zeppeli(),
                        label: {
                            
                            ZStack {
                            
                                Rectangle()
                                    .opacity(0.5)
                                    .cornerRadius(20)
                                    .foregroundColor(.black)
                                    
                                
                            VStack {
                            
                            Image("William A. Zeppeli")
                                .resizable()
                                .scaledToFit()
                                .cornerRadius(20)
                                
                            
                                Text("William A. Zeppeli")
                                    .padding(.bottom)
                            
                            }
                            .padding([.top, .leading, .trailing]).foregroundColor(.white)
                            
                            
                            }
                            })
                    
                    NavigationLink(
                        destination: Will__A__Zeppeli(),
                        label: {
                            
                            ZStack {
                            
                                Rectangle()
                                    .opacity(0.5)
                                    .cornerRadius(20)
                                    .foregroundColor(.black)
                                    
                                
                            VStack {
                            
                            Image("William A. Zeppeli")
                                .resizable()
                                .scaledToFit()
                                .cornerRadius(20)
                                
                            
                                Text("William A. Zeppeli")
                                    .padding(.bottom)
                            
                            }
                            .padding([.top, .leading, .trailing]).foregroundColor(.white)
                            
                            
                            }
                            })
                    
                    NavigationLink(
                        destination: Will__A__Zeppeli(),
                        label: {
                            
                            ZStack {
                            
                                Rectangle()
                                    .opacity(0.5)
                                    .cornerRadius(20)
                                    .foregroundColor(.black)
                                    
                                
                            VStack {
                            
                            Image("William A. Zeppeli")
                                .resizable()
                                .scaledToFit()
                                .cornerRadius(20)
                                
                            
                                Text("William A. Zeppeli")
                                    .padding(.bottom)
                            
                            }
                            .padding([.top, .leading, .trailing]).foregroundColor(.white)
                            
                            
                            }
                            })
                    
                    NavigationLink(
                        destination: Will__A__Zeppeli(),
                        label: {
                            
                            ZStack {
                            
                                Rectangle()
                                    .opacity(0.5)
                                    .cornerRadius(20)
                                    .foregroundColor(.black)
                                    
                                
                            VStack {
                            
                            Image("William A. Zeppeli")
                                .resizable()
                                .scaledToFit()
                                .cornerRadius(20)
                                
                            
                                Text("William A. Zeppeli")
                                    .padding(.bottom)
                            
                            }
                            .padding([.top, .leading, .trailing]).foregroundColor(.white)
                            
                            
                            }
                            })
                    
                    NavigationLink(
                        destination: Will__A__Zeppeli(),
                        label: {
                            
                            ZStack {
                            
                                Rectangle()
                                    .opacity(0.5)
                                    .cornerRadius(20)
                                    .foregroundColor(.black)
                                    
                                
                            VStack {
                            
                            Image("William A. Zeppeli")
                                .resizable()
                                .scaledToFit()
                                .cornerRadius(20)
                                
                            
                                Text("William A. Zeppeli")
                                    .padding(.bottom)
                            
                            }
                            .padding([.top, .leading, .trailing]).foregroundColor(.white)
                            
                            
                            }
                            })
                    
                    NavigationLink(
                        destination: Will__A__Zeppeli(),
                        label: {
                            
                            ZStack {
                            
                                Rectangle()
                                    .opacity(0.5)
                                    .cornerRadius(20)
                                    .foregroundColor(.black)
                                    
                                
                            VStack {
                            
                            Image("William A. Zeppeli")
                                .resizable()
                                .scaledToFit()
                                .cornerRadius(20)
                                
                            
                                Text("William A. Zeppeli")
                                    .padding(.bottom)
                            
                            }
                            .padding([.top, .leading, .trailing]).foregroundColor(.white)
                            
                            
                            }
                            })
                    
                    NavigationLink(
                        destination: Will__A__Zeppeli(),
                        label: {
                            
                            ZStack {
                            
                                Rectangle()
                                    .opacity(0.5)
                                    .cornerRadius(20)
                                    .foregroundColor(.black)
                                    
                                
                            VStack {
                            
                            Image("William A. Zeppeli")
                                .resizable()
                                .scaledToFit()
                                .cornerRadius(20)
                                
                            
                                Text("William A. Zeppeli")
                                    .padding(.bottom)
                            
                            }
                            .padding([.top, .leading, .trailing]).foregroundColor(.white)
                            
                            
                            }
                            })
                    
                    NavigationLink(
                        destination: Will__A__Zeppeli(),
                        label: {
                            
                            ZStack {
                            
                                Rectangle()
                                    .opacity(0.5)
                                    .cornerRadius(20)
                                    .foregroundColor(.black)
                                    
                                
                            VStack {
                            
                            Image("William A. Zeppeli")
                                .resizable()
                                .scaledToFit()
                                .cornerRadius(20)
                                
                            
                                Text("William A. Zeppeli")
                                    .padding(.bottom)
                            
                            }
                            .padding([.top, .leading, .trailing]).foregroundColor(.white)
                            
                            
                            }
                            })
                    
                    
                    
                })
                        
                       VStack {
                            
                            LazyVGrid(columns: columns, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/, spacing: /*@START_MENU_TOKEN@*/nil/*@END_MENU_TOKEN@*/, pinnedViews: /*@START_MENU_TOKEN@*/[]/*@END_MENU_TOKEN@*/, content: {
                                
                                NavigationLink(
                                    destination: Will__A__Zeppeli(),
                                    label: {
                                        
                                        ZStack {
                                        
                                            Rectangle()
                                                .opacity(0.5)
                                                .cornerRadius(20)
                                                .foregroundColor(.black)
                                                
                                            
                                        VStack {
                                        
                                        Image("William A. Zeppeli")
                                            .resizable()
                                            .scaledToFit()
                                            .cornerRadius(20)
                                            
                                        
                                            Text("William A. Zeppeli")
                                                .padding(.bottom)
                                        
                                        }
                                        .padding([.top, .leading, .trailing]).foregroundColor(.white)
                                        
                                        
                                        }
                                        })
                                
                                NavigationLink(
                                    destination: Will__A__Zeppeli(),
                                    label: {
                                        
                                        ZStack {
                                        
                                            Rectangle()
                                                .opacity(0.5)
                                                .cornerRadius(20)
                                                .foregroundColor(.black)
                                                
                                            
                                        VStack {
                                        
                                        Image("William A. Zeppeli")
                                            .resizable()
                                            .scaledToFit()
                                            .cornerRadius(20)
                                            
                                        
                                            Text("William A. Zeppeli")
                                                .padding(.bottom)
                                        
                                        }
                                        .padding([.top, .leading, .trailing]).foregroundColor(.white)
                                        
                                        
                                        }
                                        })
                                
                                NavigationLink(
                                    destination: Will__A__Zeppeli(),
                                    label: {
                                        
                                        ZStack {
                                        
                                            Rectangle()
                                                .opacity(0.5)
                                                .cornerRadius(20)
                                                .foregroundColor(.black)
                                                
                                            
                                        VStack {
                                        
                                        Image("William A. Zeppeli")
                                            .resizable()
                                            .scaledToFit()
                                            .cornerRadius(20)
                                            
                                        
                                            Text("William A. Zeppeli")
                                                .padding(.bottom)
                                        
                                        }
                                        .padding([.top, .leading, .trailing]).foregroundColor(.white)
                                        
                                        
                                        }
                                        })
                                
                                NavigationLink(
                                    destination: Will__A__Zeppeli(),
                                    label: {
                                        
                                        ZStack {
                                        
                                            Rectangle()
                                                .opacity(0.5)
                                                .cornerRadius(20)
                                                .foregroundColor(.black)
                                                
                                            
                                        VStack {
                                        
                                        Image("William A. Zeppeli")
                                            .resizable()
                                            .scaledToFit()
                                            .cornerRadius(20)
                                            
                                        
                                            Text("William A. Zeppeli")
                                                .padding(.bottom)
                                        
                                        }
                                        .padding([.top, .leading, .trailing]).foregroundColor(.white)
                                        
                                        
                                        }
                                        })
                                
                                NavigationLink(
                                    destination: Will__A__Zeppeli(),
                                    label: {
                                        
                                        ZStack {
                                        
                                            Rectangle()
                                                .opacity(0.5)
                                                .cornerRadius(20)
                                                .foregroundColor(.black)
                                                
                                            
                                        VStack {
                                        
                                        Image("William A. Zeppeli")
                                            .resizable()
                                            .scaledToFit()
                                            .cornerRadius(20)
                                            
                                        
                                            Text("William A. Zeppeli")
                                                .padding(.bottom)
                                        
                                        }
                                        .padding([.top, .leading, .trailing]).foregroundColor(.white)
                                        
                                        
                                        }
                                        })
                                
                                NavigationLink(
                                    destination: Will__A__Zeppeli(),
                                    label: {
                                        
                                        ZStack {
                                        
                                            Rectangle()
                                                .opacity(0.5)
                                                .cornerRadius(20)
                                                .foregroundColor(.black)
                                                
                                            
                                        VStack {
                                        
                                        Image("William A. Zeppeli")
                                            .resizable()
                                            .scaledToFit()
                                            .cornerRadius(20)
                                            
                                        
                                            Text("William A. Zeppeli")
                                                .padding(.bottom)
                                        
                                        }
                                        .padding([.top, .leading, .trailing]).foregroundColor(.white)
                                        
                                        
                                        }
                                        })
                                
                                NavigationLink(
                                    destination: Will__A__Zeppeli(),
                                    label: {
                                        
                                        ZStack {
                                        
                                            Rectangle()
                                                .opacity(0.5)
                                                .cornerRadius(20)
                                                .foregroundColor(.black)
                                                
                                            
                                        VStack {
                                        
                                        Image("William A. Zeppeli")
                                            .resizable()
                                            .scaledToFit()
                                            .cornerRadius(20)
                                            
                                        
                                            Text("William A. Zeppeli")
                                                .padding(.bottom)
                                        
                                        }
                                        .padding([.top, .leading, .trailing]).foregroundColor(.white)
                                        
                                        
                                        }
                                        })
                                
                                NavigationLink(
                                    destination: Will__A__Zeppeli(),
                                    label: {
                                        
                                        ZStack {
                                        
                                            Rectangle()
                                                .opacity(0.5)
                                                .cornerRadius(20)
                                                .foregroundColor(.black)
                                                
                                            
                                        VStack {
                                        
                                        Image("William A. Zeppeli")
                                            .resizable()
                                            .scaledToFit()
                                            .cornerRadius(20)
                                            
                                        
                                            Text("William A. Zeppeli")
                                                .padding(.bottom)
                                        
                                        }
                                        .padding([.top, .leading, .trailing]).foregroundColor(.white)
                                        
                                        
                                        }
                                        })
                                
                                NavigationLink(
                                    destination: Will__A__Zeppeli(),
                                    label: {
                                        
                                        ZStack {
                                        
                                            Rectangle()
                                                .opacity(0.5)
                                                .cornerRadius(20)
                                                .foregroundColor(.black)
                                                
                                            
                                        VStack {
                                        
                                        Image("William A. Zeppeli")
                                            .resizable()
                                            .scaledToFit()
                                            .cornerRadius(20)
                                            
                                        
                                            Text("William A. Zeppeli")
                                                .padding(.bottom)
                                        
                                        }
                                        .padding([.top, .leading, .trailing]).foregroundColor(.white)
                                        
                                        
                                        }
                                        })
                                
                                NavigationLink(
                                    destination: Will__A__Zeppeli(),
                                    label: {
                                        
                                        ZStack {
                                        
                                            Rectangle()
                                                .opacity(0.5)
                                                .cornerRadius(20)
                                                .foregroundColor(.black)
                                                
                                            
                                        VStack {
                                        
                                        Image("William A. Zeppeli")
                                            .resizable()
                                            .scaledToFit()
                                            .cornerRadius(20)
                                            
                                        
                                            Text("William A. Zeppeli")
                                                .padding(.bottom)
                                        
                                        }
                                        .padding([.top, .leading, .trailing]).foregroundColor(.white)
                                        
                                        
                                        }
                                        })
                            
                            })
                        }
                }
                }
            }
            
        }
        
    }
}


struct Stardust_Char_View_Previews: PreviewProvider {
    static var previews: some View {
        Stardust_Char_View()
    }
}
