//
//  Golden Wind Char View.swift
//  JOJO
//
//  Created by William Bateman on 6/17/21.
//

import SwiftUI

struct Golden_Wind_Char_View: View {
    var body: some View {
        ZStack {
            
            LinearGradient(gradient: Gradient(colors: [.black,.purple,.black]), startPoint: .top, endPoint: .bottom).ignoresSafeArea()
            
            
            ScrollView {
                
                
                
                
            }
            
            
            
        }.navigationTitle("Golden Wind").navigationBarTitleDisplayMode(.inline)
        .ignoresSafeArea()
            
        }
        




    }
    


struct Golden_Wind_Char_View_Previews: PreviewProvider {
    static var previews: some View {
        Golden_Wind_Char_View()
    }
}
